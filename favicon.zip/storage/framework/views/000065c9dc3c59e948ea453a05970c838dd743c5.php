
<?php $__env->startSection('content'); ?>


<div class="content-wrapper">
  <div class="page-heading">
    <h3 class="page-title">Product Update Information</h3>
  </div>



  <div class="page-content fade-in">
    <div class="ibox">
      <div class="ibox-head mb-3 myhead">
        <div class="ibox-title"><i class="fa fa-list-ul" aria-hidden="true"></i>&nbsp;&nbsp;Product
        Setup List</div>
        <div><a href="<?php echo e(url('manageproduct')); ?>" class="btn btn-dark rounded addbutton"><i class="fa fa-eye"></i>&nbsp;View Product</a></div>
      </div>
      <div class="ibox-body">
        <form method="post" class="btn-submit" data-id="<?php echo e($data->pdt_id); ?>">
          <?php echo csrf_field(); ?>

          <div class="row myinput">

            <div class="col-md-6 row">


              <div class="form-group col-md-12">
                <label>Item Name:</label>
                <div class="input-group">

                  <select class="form-control" name="pdt_item_id" required="">
                    <option value=""></option>
                    <?php
                    $item = DB::table('pdt_item')->where('item_status',1)->get();   
                    ?> 
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($i->item_id); ?>" <?php if ($i->item_id == $data->pdt_item_id) {
                     echo "selected";
                   } ?>><?php echo e($i->item_name_en); ?> ( <?php echo e($i->item_name_bn); ?> )</option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
               </div>
             </div>


             <div class="form-group col-md-6">
              <label>Category Name:</label>
              <div class="input-group">

                <select class="form-control" name="pdt_cat_id">
                  <option value=""></option>
                  <?php
                  $category = DB::table('pdt_category')->where('cat_status',1)->get();    
                  ?> 
                  <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($c->cat_id); ?>" <?php if ($c->cat_id == $data->pdt_cat_id) {
                   echo "selected";
                 } ?>><?php echo e($c->cat_name_en); ?> ( <?php echo e($c->cat_name_bn); ?> )</option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
             </div>
           </div>


           <div class="form-group col-md-6">
            <label>Subcategory Name:</label>
            <div class="input-group">

              <select class="form-control" name="pdt_subcat_id">
                <option value=""></option>
                <?php
                $subcategory = DB::table('pdt_subcategory')->where('subcat_status',1)->get();   
                ?> 
                <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->subcat_id); ?>"<?php if ($c->subcat_id == $data->pdt_subcat_id) {
                 echo "selected";
               } ?>><?php echo e($c->subcat_name_en); ?> ( <?php echo e($c->subcat_name_bn); ?> )</option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
           </div>
         </div>



         <div class="form-group col-md-12">
          <label>Brand Name:</label>
          <div class="input-group">

            <select class="form-control" name="pdt_brand_id">
              <option value=""></option>
              <?php
              $brand = DB::table('pdt_brand')->where('brand_status',1)->get();    
              ?> 
              <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->brand_id); ?>"<?php if ($c->brand_id == $data->pdt_brand_id) {
               echo "selected";
             } ?>><?php echo e($c->brand_name_en); ?> ( <?php echo e($c->brand_name_bn); ?> )</option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
         </div>
       </div>



       <div class="form-group col-md-12">
        <label>Product Name(EN):</label>
        <div class="input-group">
          <input class="form-control" type="text" name="pdt_name_en" id="pdt_name_en"required="" value="<?php echo e($data->pdt_name_en); ?>">
        </div>
      </div>

      <div class="form-group col-md-12">
        <label>Product Name(BN):</label>
        <div class="input-group">
          <input class="form-control" type="text" name="pdt_name_bn" id="pdt_name_bn" value=<?php echo e($data->pdt_name_bn); ?>>
        </div>
      </div>



      <div class="form-group col-md-12">
        <label>Measurement:</label>
        <select class="form-control" name="pdt_measurement">
          <option value="">Select Measurement</option>
          <?php
          $measurement = DB::table('measurement_unit')->get();    
          ?> 
          <?php $__currentLoopData = $measurement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($c->measurement_id); ?>" <?php if ($c->measurement_id == $data->pdt_measurement) {
            echo "selected";
          } ?>><?php echo e($c->measurement_unit); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>



      <div class="form-group col-md-6">
        <label>Purchase Price:</label>
        <div class="input-group">
          <input class="form-control" type="text" name="pdt_purchase_price" id="pdt_purchase_price" value=<?php echo e($data->pdt_purchase_price); ?>>
        </div>
      </div>

      <div class="form-group col-md-6">
        <label>Sale Price:</label>
        <div class="input-group">
          <input class="form-control" type="text" name="pdt_sale_price" id="pdt_sale_price" required="" value=<?php echo e($data->pdt_sale_price); ?>>
        </div>
      </div>

      <div class="form-group col-md-6">
        <label>Over Stock:</label>
        <div class="input-group">
          <input class="form-control" type="number" name="pdt_over_stock" id="pdt_over_stock" value=<?php echo e($data->pdt_over_stock); ?>>
        </div>
      </div>


      <div class="form-group col-md-6">
        <label>Shelf No:</label>
        <div class="input-group">
          <input class="form-control" type="text" name="pdt_shelf_no" id="pdt_shelf_no" value=<?php echo e($data->pdt_shelf_no); ?>>
        </div>
      </div>


      <div class="form-group col-md-6">
        <label>Order Qty:</label>
        <div class="input-group">
          <input class="form-control" type="number" name="pdt_order_qunt" id="pdt_order_qunt" value=<?php echo e($data->pdt_order_qunt); ?>>
        </div>
      </div>

      <div class="form-group col-md-6">
        <label>Suspension:</label>
        <div class="input-group">
          <input class="form-control" type="text" name="pdt_suspension" id="pdt_suspension" value=<?php echo e($data->pdt_suspension); ?>>
        </div>
      </div>

      <div class="form-group col-md-12">
        <label>Product URL:</label>
        <div class="input-group">
          <input class="form-control" type="text" name="pdt_url" id="pdt_url" value=<?php echo e($data->pdt_url); ?>>
        </div>
      </div>


    </div>

    <div class="col-md-6">

      <div class="form-group col-md-12">
        <label>Short Details:</label>
        <div class="input-group">
          <textarea class="form-control" rows="10" name="pdt_short_details" id="pdt_short_details"><?php echo e($data->pdt_short_details); ?></textarea>
        </div>
      </div>


      <div class="form-group col-md-12">
        <label>Full Details:</label>
        <div class="input-group">
          <textarea class="form-control" rows="10" name="pdt_details" id="pdt_details"><?php echo e($data->pdt_details); ?></textarea>
        </div>
      </div>

      <div class="form-group col-md-12">
        <label>Condition:</label>
        <div class="input-group">
          <textarea class="form-control" rows="10" name="pdt_condition" id="pdt_condition"><?php echo e($data->pdt_condition); ?></textarea>
        </div>
      </div>  

      <div class="form-group col-md-12">
        <label>Status:</label>
        <div class="input-group">
          <select class="form-control" name="pdt_status" id="pdt_status">
            <?php if($data->pdt_status == 1): ?>
            <option value="1">Active</option>
            <option value="0">Inactive</option>
            <?php else: ?>
            <option value="0">Inactive</option>
            <option value="1">Active</option>
            <?php endif; ?>
          </select>
        </div>
      </div>


      <br><br>

      <div class="modal-footer border-0">
        <button type="button" class="btn btn-secondary border-0" onClick="window.location.reload();">Close</button>
        <button type="submit" class="btn btn-success button border-0">Save</button>
        <button type="button" class="btn btn-success loading border-0">Loading...</button>
      </div>

    </div>











  </div>
</form>

</div>
</div>

</div>
</div>

<!-------End Table--------->




<script type="text/javascript">
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });



  $('.loading').hide();
  $(".btn-submit").submit(function(e){
    e.preventDefault();
    var data = $(this).serialize();
    var id = $(this).data("id");

    $.ajax({
      url:'<?php echo e(url('updateproduct')); ?>/'+id,
      method:'POST',
      data:data,
      beforeSend:function(response) { 
        $('.loading').show();
        $('.button').hide();

      },
      success:function(response){

        Command:toastr["success"]("Data Update Successfully Done")
        toastr.options = {
          "closeButton": true,
          "debug": false,
          "newestOnTop": false,
          "progressBar": true,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "3000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        }

        
        $('.loading').hide();
        $('.button').show();


      },

      error:function(error){
        console.log(error)
      }
    });
  });

  // End Add Data


</script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/product/editproduct.blade.php ENDPATH**/ ?>