
<?php $__env->startSection('content'); ?>



<div class="content-wrapper">
	<div class="page-heading">
		<h3 class="page-title">Edit Purchase Payment</h3>
	</div>



	<div class="page-content fade-in">
		<div class="ibox">
			<div class="ibox-head mb-3 myhead">
				<div class="ibox-title"><i class="fa fa-list-ul" aria-hidden="true"></i>&nbsp;&nbsp;Edit Purchase Payment</div>
				<div><a href="<?php echo e(url('purchasepaymentlist')); ?>" class="btn btn-dark rounded addbutton"><i class="fa fa-plus"></i>&nbsp;Purchase Payment List</a></div>
			</div>
			<div class="ibox-body">
				<form method="post"  class="reloadform myinput btn-submit" data-id="<?php echo e($data->id); ?>">
					<?php echo csrf_field(); ?>

					<div class="col-md-12 p-0 row">
						
						<div class="form-group col-md-4">
							<label>Supplier Name:</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-user"></i></div>
								<select class="form-control select2_demo_1" name="suplier_id" id=
								"suplier_id" required="" onchange="getsupplierphone()">
								<option value="">Select Supplier</option>
								<?php
								$supplier = DB::table('supplier_info')->get();		
								?> 
								<?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($i->supplier_id); ?>" <?php if ($i->supplier_id == $data->suplier_id) {
									echo "selected";
								} ?>><?php echo e($i->supplier_name_en); ?>  <?php echo e($i->supplier_name_bn); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<div class="input-group-addon border border-left-0" data-toggle="modal" data-target="#exampleModalCenters"><i class="fa fa-plus-circle text-primary"></i></div>
						</div>
					</div>


					<div class="form-group col-md-4">
						<label>Mobile Number:</label>
						<div class="input-group suppliermobile">
							<div class="input-group-addon"><i class="fa fa-phone"></i></div>
							<input type='number'  name='supplier_phone' id='supplier_phone' class='form-control' placeholder='Mobile' readonly="" value="<?php echo e($supplier_phone->supplier_phone); ?>">
						</div>
					</div>



					<div class="form-group col-md-4">
						<label>Previous Due:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="text" name="due" id="due" class="form-control"  readonly="" value="<?php echo e($totaldue); ?>">
							
						</div>
					</div>
					


					<?php
					 $explode = explode('-',$data->payment_date);
					 $payment_date = $explode[1].'/'.$explode[2].'/'.$explode[0]; 
					?>

					<div class="form-group col-md-4">
						<label>Date:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
							<input type="text" name="payment_date" id="payment_date" placeholder="Payment Date" class="form-control" required="" autocomplete="off" value="<?php echo e($payment_date); ?>">
							
						</div>
					</div>







					<div class="form-group col-md-4">
						<label>Payment Money:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="number" name="payment" id="payment" class="form-control" required="" value="<?php echo e($data->payment); ?>">
							
						</div>
					</div>




					<div class="form-group col-md-4">
						<label>Payment By:</label>
						<div class="input-group">
							<select class="form-control" name="payment_type" id="payment_type">
								<option value="<?php echo e($data->payment_type); ?>"><?php echo e($data->payment_type); ?></option>
								<option value="Cash">Cash</option>
								<option value="Bank">Bank</option>
								<option value="Mobile Banking">Mobile Banking</option>

							</select>
							
						</div>
					</div>


					<div class="form-group col-md-4">
						<label>Comment:</label>
						<div class="input-group">
							<input type="text" name="comment" id="comments" placeholder="Comment" class="form-control" value="<?php echo e($data->comment); ?>">
							
						</div>
					</div>




				</div>


				<div class="col-12 border p-4 mt-4">
					<center><input type="submit" value="Submit Now" class="btn btn-success button" style="width: 200px; font-weight: bold; border-radius: 30px;"></center>

					<center><input type="button" value="Loading..." class="btn btn-success loading" style="width: 200px; font-weight: bold; border-radius: 30px;"></center>
				</div>


			</form>

		</div>
	</div>

</div>
</div>

<!-------End Table--------->




<script type="text/javascript">
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		}
	});


	function getsupplierphone(){
		let supplier_id = $("#suplier_id").val();

		$.ajax({
			url: "<?php echo e(url('getsupplierphone')); ?>/"+supplier_id,
			type: 'get',
			data:{},
			success: function (data)
			{
				$(".suppliermobile").html(data);
				previousdue();
				
			},
			error:function(errors){
				alert("Select Supplier")
			}
		});

	}

	function previousdue(){
		let supplier_id = $("#suplier_id").val();
		$.ajax({
			url: "<?php echo e(url('getsuplierpreviousdue')); ?>/"+supplier_id,
			type: 'get',
			success: function (data)
			{
				$("#due").val(data);
				
			},
			error:function(errors){
				alert("Select Supplier")
			}
		});

	}



	$('.loading').hide();
	$(".btn-submit").submit(function(e){
		e.preventDefault();

		var data = $(this).serialize();
		var id = $(this).data("id");

		$.ajax({
			url:'<?php echo e(url('updatepurchasepayment')); ?>/'+id,
			method:'POST',
			data:data,
			beforeSend:function(response) { 
				$('.loading').show();
				$('.button').hide();

			},
			success:function(response){

				Command:toastr["success"]("Update Payment Successfully Done")
				toastr.options = {
					"closeButton": true,
					"debug": false,
					"newestOnTop": false,
					"progressBar": true,
					"positionClass": "toast-top-right",
					"preventDuplicates": false,
					"onclick": null,
					"showDuration": "300",
					"hideDuration": "1000",
					"timeOut": "3000",
					"extendedTimeOut": "1000",
					"showEasing": "swing",
					"hideEasing": "linear",
					"showMethod": "fadeIn",
					"hideMethod": "fadeOut"
				}


				$('.loading').hide();
				$('.button').show();
				previousdue();



			},

			error:function(error){
				console.log(error)
			}
		});
	});





</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/purchase/editpurchasepaymententry.blade.php ENDPATH**/ ?>