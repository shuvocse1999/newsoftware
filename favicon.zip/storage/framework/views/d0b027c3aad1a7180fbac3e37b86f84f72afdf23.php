<?php $i=1;  ?>
<?php if(isset($data)): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="tr<?php echo e($d->pdt_id); ?>">
	<td><?php echo e($i++); ?></td>
	<td><?php echo e($d->item_name_en); ?><br><?php echo e($d->item_name_bn); ?></td>
	<td><?php echo e($d->pdt_name_en); ?><br><?php echo e($d->pdt_name_bn); ?></td>
	<td><?php echo e($d->pdt_purchase_price); ?> Tk.</td>
	<td><?php echo e($d->pdt_sale_price); ?> Tk.</td>
	<td><?php echo e($d->measurement_unit); ?></td>
	<td><?php echo e($d->pdt_over_stock); ?></td>
	<td>
		<?php if($d->pdt_status == 1): ?>
		<span class="btn btn-success btn-sm border-0">Active</span>
		<?php else: ?>
		<span class="btn btn-warning btn-sm border-0">Inactive</span>
		<?php endif; ?>
	</td>
	
	
	<td>
		<a href="<?php echo e(url('editproduct/'.$d->pdt_id)); ?>"  class="btn btn-info border-0 edit text-light" ><i class="fa fa-pencil-square-o"></i></a>
		<a onclick="return confirm('Are you sure?')" class="delete btn btn-danger  border-0 text-light" data-id="<?php echo e($d->pdt_id); ?>"><i class="fa fa-trash-o"></i></a>
	</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/product/searchproduct.blade.php ENDPATH**/ ?>