
<!DOCTYPE html>
<html>
<head>
	<title>Bank Transaction Reports</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap" rel="stylesheet">
</head>
<body>


	<?php
	$company_info = DB::table("company_info")->first();

	?>


	<div class="invoice border">

		<center><img src="<?php echo e(url($company_info->banner)); ?>" id="header_image" class="img-fluid"></center>


		<table class="table table-bordered">

			<tr>
				<td colspan="5" style="text-align:center;font-size: 16px;text-transform: uppercase;font-weight: bold;"><b>Bank Transaction Voucher</b></td>
			</tr>
			<tr>
				<td colspan="2">
					Date : <?php echo e($data->deposit_withdraw_date); ?><br>
					Voucher/Cheque/TrnID No : <?php echo e($data->vouchar_cheque_no); ?> <br>
					Bank Info : <?php echo e($data->bank_name); ?>, <?php echo e($data->account_number); ?>


				</td>
				<td colspan="3">
					Transaction : <?php echo e($data->transaction_type); ?><br>
					Prepared By : <?php echo e($data->name); ?><br>
					Print  : <?php echo e(date("d M Y")); ?><br>
				</tr>



				<!-- <thead> -->
					<tr>
						<th>Date</th>
						<th>Bank Name</th>
						<th>Account Number</th>
						<th>Transaction Type</th>
						<th>Amount</th>

					</tr>
					<!-- </thead> -->



					<tbody>


						<?php if(isset($data)): ?>

						<tr>
							<td><?php echo e($data->deposit_withdraw_date); ?></td>
							<td><?php echo e($data->bank_name); ?></td>
							<td><?php echo e($data->account_number); ?></td>
							<td><?php echo e($data->transaction_type); ?></td>
							<th><?php echo e($data->deposit_withdraw_amount); ?>/-</th>
						</tr>
						<?php endif; ?>



					</tbody>




				</table>




				<br>
				<center><a href="#" class="btn btn-danger btn-sm print w-10" onclick="window.print();">Print</a></center>
				<br>


			</div>






			<style type="text/css">

				body{
					font-family: 'Lato';
				}


				.invoice{
					background: #fff;
					border:none!important;
					padding:30px;

				}

				.invoice span{
					font-size: 15px;
				}

				thead{
					font-size: 15px;
				}

				tbody{
					font-size: 13px;
				}

				.table-bordered td, .table-bordered th{
					border: 1px solid #585858 !important;
					box-shadow: none;
					border-bottom: 1px solid #585858;
				}

				.table-bordered tr{
					border: 1px solid #585858 !important;
				}


				tbody {
					border: none !important;
				}


				@media    print
				{

					.table-bordered tr{
						border: 1px solid #585858 !important;
					}

					@page    {
						/*size: 7in 15.00in;*/
						margin: 1mm 1mm 1mm 1mm;
						padding: 10px;
					}

					.print{
						display: none;
					}

					.invoice span{
						font-size: 22px;
					}
					/*@page    { size: 10cm 20cm landscape; }*/

				}


			</style>


		</body>
		</html><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/bank/bankvoucher.blade.php ENDPATH**/ ?>