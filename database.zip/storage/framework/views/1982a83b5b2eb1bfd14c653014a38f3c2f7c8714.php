
<!DOCTYPE html>
<html>
<head>
	<title>Bank Transaction Reports</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap" rel="stylesheet">
</head>
<body>


	<?php
	$company_info = DB::table("company_info")->first();

	?>


	<div class="invoice border">

		<center><img src="<?php echo e(url($company_info->banner)); ?>" id="header_image" class="img-fluid"></center>


		<table class="table table-bordered">
			
			<tr>
				<td colspan="4" style="text-align:center;font-size: 16px;text-transform: uppercase;font-weight: bold;"><b>Bank Statement Reports</b><br>



					<?php if($type == "1"): ?>
					<span>Date :&nbsp;&nbsp;<?php echo e($date1); ?> </span>
					<?php endif; ?>

					<?php if($type == "3"): ?>

					<span>Month :&nbsp;&nbsp;
						<?php if($month ==='01'): ?>(January)<?php endif; ?>
						<?php if($month ==='02'): ?>(February)<?php endif; ?>
						<?php if($month ==='03'): ?>(March)<?php endif; ?>
						<?php if($month ==='04'): ?>(April)<?php endif; ?>
						<?php if($month ==='05'): ?>(May)<?php endif; ?>
						<?php if($month ==='06'): ?>(June)<?php endif; ?>
						<?php if($month ==='07'): ?>(July)<?php endif; ?>
						<?php if($month ==='08'): ?>(August)<?php endif; ?>
						<?php if($month ==='09'): ?>(September)<?php endif; ?>
						<?php if($month ==='10'): ?>(October)<?php endif; ?>
						<?php if($month ==='11'): ?>(November)<?php endif; ?>
						<?php if($month ==='12'): ?>(December)<?php endif; ?> 
					</span>

					<?php endif; ?>

					<?php if($type == "4"): ?>

					<span>Year :&nbsp;&nbsp;<?php echo e($year); ?>

					</span>

					<?php endif; ?>

					<?php if($type == "2" ): ?>

					<span>From :&nbsp;&nbsp;<?php echo e($date1); ?> - To :&nbsp;&nbsp;<?php echo e($date2); ?> </span>

					<?php endif; ?>

				</tr>

				<?php if(isset($data[0])): ?>

				<tr>
					<th>Bank Name</th>
					<td><?php echo e($data[0]->bank_name); ?></td>
					<th>Account Number</th>
					<td><?php echo e($data[0]->account_number); ?></td>


				</tr>

				<tr>
					<th>Account Type</th>
					<td><?php echo e($data[0]->account_type); ?></td>

					<th>Print Date</th>
					<td><?php echo e(date('d M Y')); ?></td>
				</tr>

				<?php endif; ?>

			</table>

			<table class="table table-bordered">

				<!-- <thead> -->
					<tr>
						<th>SL</th>
						<th>Date</th>
						<th>Deposit</th>
						<th>Withdraw</th>
						<th>Cost</th>
						<th>Interest</th>
						<th>Balance</th>

					</tr>
					<!-- </thead> -->



					<tbody>

						<?php
						$i=1;
						$totaldeposit = 0;
						$totalwithdraw = 0;
						$totalcost = 0;
						$totalinsterest = 0;
						?>
						<?php if(isset($data)): ?>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							<td><?php echo e($i++); ?></td>
							<td><?php echo e($d->deposit_withdraw_date); ?></td>
							<td>
								<?php if($d->transaction_type == "Deposit"): ?>
								<?php
								$totaldeposit += $d->deposit_withdraw_amount;
								?>
								<?php echo e($d->deposit_withdraw_amount); ?>

								<?php else: ?>
								-
								<?php endif; ?>
							</td>

							<td>
								<?php if($d->transaction_type == "Withdraw"): ?>
								<?php
								$totalwithdraw += $d->deposit_withdraw_amount;
								?>
								<?php echo e($d->deposit_withdraw_amount); ?>

								<?php else: ?>
								-
								<?php endif; ?>
							</td>

							<td>
								<?php if($d->transaction_type == "Bank-Cost"): ?>
								<?php
								$totalcost += $d->deposit_withdraw_amount;
								?>
								<?php echo e($d->deposit_withdraw_amount); ?>

								<?php else: ?>
								-
								<?php endif; ?>
							</td>

							<td>
								<?php if($d->transaction_type == "Bank-Insterest"): ?>
								<?php
								$totalinsterest += $d->deposit_withdraw_amount;
								?>
								<?php echo e($d->deposit_withdraw_amount); ?>

								<?php else: ?>
								-
								<?php endif; ?>
							</td>

							<td>
								<?php echo e(($totaldeposit+$totalinsterest)-($totalwithdraw+$totalcost)); ?>

							</td>


						</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>



					</tbody>

					<tr>
						<th colspan="2" class="text-right">Total</th>
						<th><?php echo e($totaldeposit); ?>/-</th>
						<th><?php echo e($totalwithdraw); ?>/-</th>
						<th><?php echo e($totalcost); ?>/-</th>
						<th><?php echo e($totalinsterest); ?>/-</th>
						<th><?php echo e(($totaldeposit+$totalinsterest)-($totalwithdraw+$totalcost)); ?>/-</th>
					</tr>



				</table>




				<br>
				<center><a href="#" class="btn btn-danger btn-sm print w-10" onclick="window.print();">Print</a></center>
				<br>


			</div>






			<style type="text/css">

				body{
					font-family: 'Lato';
				}


				.invoice{
					background: #fff;
					border:none!important;
					padding:30px;

				}

				.invoice span{
					font-size: 15px;
				}

				thead{
					font-size: 15px;
				}

				tbody{
					font-size: 13px;
				}

				.table-bordered td, .table-bordered th{
					border: 1px solid #585858 !important;
					box-shadow: none;
					border-bottom: 1px solid #585858;
				}

				.table-bordered tr{
					border: 1px solid #585858 !important;
				}


				tbody {
					border: none !important;
				}


				@media    print
				{

					.table-bordered tr{
						border: 1px solid #585858 !important;
					}

					@page    {
						/*size: 7in 15.00in;*/
						margin: 1mm 1mm 1mm 1mm;
						padding: 10px;
					}

					.print{
						display: none;
					}

					.invoice span{
						font-size: 22px;
					}
					/*@page    { size: 10cm 20cm landscape; }*/

				}


			</style>


		</body>
		</html><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/bank/bankstatementreportstab.blade.php ENDPATH**/ ?>