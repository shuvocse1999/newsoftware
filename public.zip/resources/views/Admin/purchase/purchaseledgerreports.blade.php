
<!DOCTYPE html>
<html>
<head>
  <title>Purchase Reports</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap" rel="stylesheet">
</head>
<body>


  @php
  $company_info = DB::table("company_info")->first();

  @endphp


  <div class="invoice border">

    <center><img src="{{ url($company_info->banner) }}" id="header_image"></center>


    <table class="table table-bordered">
      <tr>

        <td colspan="9" style="text-align:center;font-size: 16px;text-transform: uppercase;"><b>Purchase Ledger Reports</b>
          <br>
          <div style="font-size: 13px;">

  
            
          </div>
        </td>
      </tr>
      <tr>

      </tr>



      <!-- <thead> -->
       <tr>
         <th>SL</th>
         <th>Invoice No</th>
         <th>Invoice Date</th>
         <th>Supplier Info.</th>
         <th>Total Amount</th>
         <th>Discount</th>
         <th>Paid</th>
         <th>Due</th>
         <th>Transaction</th>
       </tr>
       <!-- </thead> -->



       <tbody>

        @php
        $i=1;
        @endphp
        @if(isset($data))
        @foreach($data as $d)

        <tr>
          <td>{{ $i++ }}</td>
          <td>{{ $d->invoice_no }}</td>
          <td>{{ $d->invoice_date }}</td>
          <td>{{ $d->supplier_name_en }}, {{ $d->supplier_phone }}</td>
          <td>{{ $d->total_amount }} Tk</td>
          <td>{{ $d->discount }} Tk</td>
          <td>{{ $d->paid }} Tk</td>
          <td>{{ $d->due }} Tk</td>
          <td>{{ $d->transaction_type }}</td>

        </tr>

        @endforeach
        @endif


      </tbody>



    </table>




    <br>
    <center><a href="#" class="btn btn-danger btn-sm print w-10" onclick="window.print();">Print</a></center>
    <br>


    <center><a style="font-size: 12px;">Software Developed by SBIT. For query: 01840241895</a></center>

  </div>






  <style type="text/css">

    body{
      font-family: 'Lato';
    }

    #header_image
    {
      width:100%;
      height: 140px;

    }
    .invoice{
      background: #f9f9f9;
      size: 21cm 29.7cm;
      margin: 0mm 45mm 30mm 45mm;
    }
    .invoice img{
      height: 80px;
    }
    .invoice span{
      font-size: 15px;
    }

    thead{
      font-size: 15px;
    }

    tbody{
      font-size: 13px;
    }

    .table-bordered td, .table-bordered th{
      border: 1px solid #585858 !important;
      box-shadow: none;
      border-bottom: 1px solid #585858;
    }

    .table-bordered tr{
      border: 1px solid #585858 !important;
    }


    tbody {
      border: none !important;
    }


    @media  print
    {

      .table-bordered tr{
        border: 1px solid #585858 !important;
      }

      @page  {
        /*size: 7in 15.00in;*/
        margin: 1mm 1mm 1mm 1mm;
        padding: 10px;
      }

      .print{
        display: none;
      }

      .invoice span{
        font-size: 22px;
      }
      /*@page  { size: 10cm 20cm landscape; }*/

    }


  </style>


</body>
</html>