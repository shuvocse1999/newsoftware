
<?php $__env->startSection('content'); ?>



<div class="content-wrapper">
	<div class="page-heading">
		<h3 class="page-title">Purchase Information</h3>
	</div>



	<div class="page-content fade-in">
		<div class="ibox">
			<div class="ibox-head mb-3 myhead">
				<div class="ibox-title"><i class="fa fa-list-ul" aria-hidden="true"></i>&nbsp;&nbsp;Add Purchase</div>
				<div><a href="<?php echo e(url('allpurchaseledger')); ?>" class="btn btn-dark rounded addbutton"><i class="fa fa-plus"></i>&nbsp;All Purchase</a></div>
			</div>
			<div class="ibox-body">
				<form method="post" action="<?php echo e(url("purchaseledger")); ?>" class="reloadform myinput" target="_blank">
					<?php echo csrf_field(); ?>

					<div class="col-md-12 p-0 row">
						
						<div class="form-group col-md-3">
							<label>Supplier Name:</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-user"></i></div>
								<select class="form-control select2_demo_1" name="supplier_id" id=
								"supplier_id" required="" onchange="getsupplierphone();">
								<option value="">Select Supplier</option>
								<?php
								$supplier = DB::table('supplier_info')->get();		
								?> 
								<?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($i->supplier_id); ?>"><?php echo e($i->supplier_name_en); ?>  <?php echo e($i->supplier_name_bn); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<div class="input-group-addon border border-left-0" data-toggle="modal" data-target="#exampleModalCenters"><i class="fa fa-plus-circle text-primary"></i></div>
						</div>
					</div>


					<div class="form-group col-md-2">
						<label>Mobile Number:</label>
						<div class="input-group suppliermobile">
							<input type='number'  name='supplier_phone' id='supplier_phone' class='form-control' placeholder='Mobile'>
						</div>
					</div>



					<div class="form-group col-md-2">
						<label>Previous Due:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="text" name="due" name="due" class="form-control" value="0.00" readonly="">
							
						</div>
					</div>


					<div class="form-group col-md-2">
						<label>Invoice Number:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-envelope"></i></div>
							<input type="text"  name="invoice_no" id="invoice_no" class="form-control" value="<?php echo e($invoice_no); ?>" readonly="">
							
						</div>
					</div>


					<div class="form-group col-md-3">
						<label>Date:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
							<input type="text" name="invoice_date" id="datepicker" placeholder="Invoice Date" class="form-control" required="" autocomplete="off">
							
						</div>
					</div>



					<div class="col-md-9">
						<div class="row">
							<div class="col-md-4">

								<div class="form-group">
									<label>Item Name:</label>
									<div class="input-group">

										<select class="form-control" name="item_id" id=
										"item_id" onchange="getproduct()">
										<option value="">Select Item</option>
										<?php
										$item = DB::table('pdt_item')->where('item_status',1)->get();		
										?> 
										<?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($i->item_id); ?>"><?php echo e($i->item_name_en); ?> <?php echo e($i->item_name_bn); ?> </option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<div class="input-group-addon border border-left-0" data-toggle="modal" data-target="#exampleModalCenter2"><i class="fa fa-plus-circle text-primary"></i></div>
								</div>
							</div>

						</div>

						<div class="col-md-8">


							<div class="form-group">
								<label>Product Name:</label>
								<div class="input-group">

									<select class="form-control select2_demo_1" name="pdt_id" id=
									"pdt_id"  onchange="return purchaseproductcart()">
									<option value="">Select Product</option>
									<?php
									$product = DB::table('pdt_productinfo')->where('pdt_status',1)->get();		
									?> 
									<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($i->pdt_id); ?>"><?php echo e($i->pdt_name_en); ?> <?php echo e($i->pdt_name_bn); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<div class="input-group-addon border border-left-0" data-toggle="modal" data-target="#exampleModalCenter3"><i class="fa fa-plus-circle text-primary"></i></div>
							</div>
						</div>


					</div>
				</div>


				<div class="col-md-12 p-0 mt-2">
					<table class="table table-bordered table-responsive purchase">
						<thead class="bg-dark text-light">
							<tr>
								<th>SL</th>
								<th>Name</th>
								<th>Quantity</th>
								<th>Unit Price</th>
								
								<th>Sub Total</th>
								<th>Action</th>

							</tr>
						</thead>

						<tbody id="showdata">
							
						</tbody>
					</table>
				</div>




			</div>




			<div class="col-md-3">
				<div class="ibox-head myhead2 p-0">
					<div class="ibox-title2"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Account</div>
				</div>

				<div class="col-md-12 bg-light p-3">
					<div class="form-group">
						<label>Total Amount:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="text" id="totalamount" name="totalamount" class="form-control"  readonly="">
							
						</div>
					</div>

					<div class="form-group">
						<label>Discount:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="text" id="discount" name="discount" class="form-control" placeholder="Discount" onkeyup="calculatediscount();">
							
						</div>
					</div>


					<div class="form-group">
						<label>Grand Total:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="text" id="grandtotal" name="grandtotal" class="form-control"  readonly="">
							
						</div>
					</div>


					<div class="form-group">
						<label>Paid:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="text" id="paid" name="paid" class="form-control" placeholder="Paid" onkeyup="calculatedue()" required="">
							
						</div>
					</div>


					<div class="form-group">
						<label>Due:</label>
						<div class="input-group">
							<div class="input-group-addon"><i class="fa fa-money"></i></div>
							<input type="text" id="due" name="due" class="form-control"  readonly="">
							
						</div>
					</div>

					<div class="form-group">
						<label>Payment By:</label>
						<div class="input-group">
							<select class="form-control" name="transaction_type" id="transaction_type">
								<option value="Cash">Cash</option>
								<option value="Bank">Bank</option>
								<option value="Mobile Banking">Mobile Banking</option>

							</select>
							
						</div>
					</div>

				</div>

			</div>






		</div>


		<div class="col-12 border p-4 mt-4">
			<center><input type="submit" name="" value="Create Invoice" class="btn btn-success" style="width: 200px; font-weight: bold; border-radius: 30px;"></center>
		</div>


	</form>

</div>
</div>

</div>
</div>

<!-------End Table--------->




<script type="text/javascript">
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		}
	});





	function getproduct(){
		let item_id = $("#item_id").val();
		$.ajax({
			url: "<?php echo e(url('getproductajax')); ?>/"+item_id,
			type: 'get',
			data:{},
			success: function (data)
			{
				$("#pdt_id").html(data);
			},
			error:function(errors){
				alert("Select Item")
			}
		});

	}

	function getsupplierphone(){
		let supplier_id = $("#supplier_id").val();
		$.ajax({
			url: "<?php echo e(url('getsupplierphone')); ?>/"+supplier_id,
			type: 'get',
			data:{},
			success: function (data)
			{
				$(".suppliermobile").html(data);
			},
			error:function(errors){
				alert("Select Supplier")
			}
		});

	}




	showpurchaseproductcart();


	function purchaseproductcart(){
		let pdt_id = $("#pdt_id").val();

		$.ajax({
			url: "<?php echo e(url('purchaseproductcart')); ?>/"+pdt_id,
			type: 'GET',
			success: function (data)
			{
				Command:toastr["success"]("Product Added Successfully Done")
				toastr.options = {
					"closeButton": true,
					"debug": false,
					"newestOnTop": false,
					"progressBar": true,
					"positionClass": "toast-top-right",
					"preventDuplicates": false,
					"onclick": null,
					"showDuration": "300",
					"hideDuration": "1000",
					"timeOut": "3000",
					"extendedTimeOut": "1000",
					"showEasing": "swing",
					"hideEasing": "linear",
					"showMethod": "fadeIn",
					"hideMethod": "fadeOut"
				}



				showpurchaseproductcart();
				


			},
			error:function(errors){
				alert("Select Products");
			}
		});

	}





	function showpurchaseproductcart(){
		$.ajax({
			url: "<?php echo e(url('showpurchaseproductcart')); ?>",
			type: 'get',
			data:{},
			success: function (data)
			{
				$("#showdata").html(data);

				let totalpurchaseamount = $("#totalpurchaseamount").val();
				$("#totalamount").val(totalpurchaseamount);
				$("#grandtotal").val(totalpurchaseamount);
				
				
			},
			error:function(errors){
				alert("errors")
			}
		});

	}




	function qtyupdate(id){

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		let purchase_quantity = $("#purchase_quantity"+id).val();

		$.ajax({
			url: "<?php echo e(url('qtyupdate')); ?>/"+id,
			type: 'POST',
			data:{purchase_quantity:purchase_quantity},
			success: function (data)
			{
				Command:toastr["success"]("Product Quentity Update")
				toastr.options = {
					"closeButton": true,
					"debug": false,
					"newestOnTop": false,
					"progressBar": true,
					"positionClass": "toast-top-right",
					"preventDuplicates": false,
					"onclick": null,
					"showDuration": "300",
					"hideDuration": "1000",
					"timeOut": "3000",
					"extendedTimeOut": "1000",
					"showEasing": "swing",
					"hideEasing": "linear",
					"showMethod": "fadeIn",
					"hideMethod": "fadeOut"
				}

				showpurchaseproductcart();
			},
			error:function(errors){
				alert("errors")
			}
		});

	}




	function purchasepriceupdate(id){

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		let per_unit_cost = $("#per_unit_cost"+id).val();

		$.ajax({
			url: "<?php echo e(url('purchasepriceupdate')); ?>/"+id,
			type: 'POST',
			data:{per_unit_cost:per_unit_cost},
			success: function (data)
			{
				Command:toastr["success"]("Product Price Update")
				toastr.options = {
					"closeButton": true,
					"debug": false,
					"newestOnTop": false,
					"progressBar": true,
					"positionClass": "toast-top-right",
					"preventDuplicates": false,
					"onclick": null,
					"showDuration": "300",
					"hideDuration": "1000",
					"timeOut": "3000",
					"extendedTimeOut": "1000",
					"showEasing": "swing",
					"hideEasing": "linear",
					"showMethod": "fadeIn",
					"hideMethod": "fadeOut"
				}

				showpurchaseproductcart();
			},
			error:function(errors){
				alert("errors")
			}
		});

	}


	


	function calculatediscount(){
		let total     = $("#totalamount").val();
		let discount  = $("#discount").val();



		if (discount != "" && discount>0) {
			let totaldiscount         = (parseFloat(total)-parseFloat(discount));
			$("#grandtotal").val(totaldiscount);

		}

		calculatedue();
		$("#due").val(0);
	}

	function calculatedue(){
		let grandtotal = $("#grandtotal").val();
		let paid       = $("#paid").val()

		let due = (parseFloat(grandtotal)-parseFloat(paid));
		$("#due").val(due);

		calculatediscount();

	}






</script>









<!-- Supplier Modal -->
<div class="modal fade" id="exampleModalCenters" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitles" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">

		<div class="modal-content rounded">
			<div class="modal-header bg-dark text-light">
				<h5 class="modal-title" id="exampleModalCenterTitles"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add New Supplier</h5>
				<button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body editdata myinput">

				<form method="post" class="btn-submit" action="<?php echo e(url('supplierinsert2')); ?>" style="max-width: 700px; margin: 0 auto;">
					<?php echo csrf_field(); ?>

					<div class="row myinput">
						<?php
						$branch = DB::table('branch_info')->get();
						?>

						<div class="form-group col-md-12">
							<label>Branch Name:</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-check-square-o"></i></div>
								<select class="form-control" name="supplier_branch_id" id="supplier_branch_id">
									<option value="">Select Branch</option>
									<?php if(isset($branch)): ?>
									<?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($c->branch_id); ?>"><?php echo e($c->branch_name_en); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>

								</select>
							</div>
						</div>



						<div class="form-group col-md-6">
							<label>Supplier Name(EN):</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-text-width"></i></div>
								<input class="form-control" type="text" name="supplier_name_en" id="supplier_name_en"  required="">
							</div>
						</div>



						<div class="form-group col-md-6">
							<label>Supplier Mobile:</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-phone"></i></div>
								<input class="form-control" type="number" name="supplier_phone" id="supplier_phone"  required="">
							</div>
						</div>



						<div class="form-group col-md-12">
							<label>Supplier Address:</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-location-arrow"></i></div>
								<textarea class="form-control" rows="3" name="supplier_address" id="supplier_address" required=""></textarea>
							</div>
						</div>

						<div class="col-md-12">
							<div class="col-md-12 mb-3 text-success border p-3 text-center bg-light font-weight-bold">Company Details:</div>
						</div>

						<div class="form-group col-md-12">
							<label>Company name:</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-text-width"></i></div>
								<input class="form-control" type="text"  name="supplier_company_name" id="supplier_company_name" required="">
							</div>
						</div>




						<div class="form-group col-md-12">
							<label>Company Address:</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-location-arrow"></i></div>
								<textarea class="form-control" rows="3" name="supplier_company_address" id="supplier_company_address" required=""></textarea>
							</div>
						</div>




						<div class="modal-footer border-0">
							<button type="button" class="btn btn-secondary border-0" onClick="window.location.reload();">Close</button>
							<button type="submit" class="btn btn-success button border-0">Save</button>
						</div>



					</div>
				</form>

			</div>


		</div>
	</div>
</div>
<!--End Supplier Modal -->







<!-- Item Modal -->
<div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<form method="post" class="btn-submit" action="<?php echo e(url('iteminsert2')); ?>">
			<?php echo csrf_field(); ?>
			<div class="modal-content rounded">
				<div class="modal-header bg-dark text-light">
					<h5 class="modal-title" id="exampleModalCenterTitle"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add New Item</h5>
					<button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body myinput">

					<div class="row">
						<div class="form-group col-md-12">
							<label>Item Name(EN):</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-text-width"></i></div>
								<input class="form-control" type="text" name="item_name_en" id="item_name_en" placeholder="Item Name(EN)" required="">
							</div>
						</div>

						<div class="form-group col-md-12">
							<label>Item Name(BN):</label>
							<div class="input-group">
								<div class="input-group-addon"><i class="fa fa-text-width"></i></div>
								<input class="form-control" type="text" name="item_name_bn" id="item_name_bn" placeholder="Item Name(BN)">
							</div>
						</div>

						

					</div>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary border-0" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-success button border-0">Save</button>
				</div>
			</form>
		</div>
	</div>


	<!-- End Item Modal -->








	<!-- Product Modal -->
	<div class="modal fade" id="exampleModalCenter3" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
			<form method="post" class="btn-submit" action="<?php echo e(url('productinsert2')); ?>">
				<?php echo csrf_field(); ?>
				<div class="modal-content rounded">
					<div class="modal-header bg-dark text-light">
						<h5 class="modal-title" id="exampleModalCenterTitle"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add New Product</h5>
						<button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body myinput">

						<div class="row">
							<div class="form-group col-md-12">
								<label>Item Name(EN):</label>
								<div class="input-group">
									<div class="input-group-addon"><i class="fa fa-text-width"></i></div>
									<input class="form-control" type="text" name="item_name_en" id="item_name_en" placeholder="Item Name(EN)" required="">
								</div>
							</div>

							<div class="form-group col-md-12">
								<label>Item Name(BN):</label>
								<div class="input-group">
									<div class="input-group-addon"><i class="fa fa-text-width"></i></div>
									<input class="form-control" type="text" name="item_name_bn" id="item_name_bn" placeholder="Item Name(BN)">
								</div>
							</div>



						</div>

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary border-0" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-success button border-0">Save</button>
					</div>
				</form>
			</div>
		</div>


		<!-- End Product Modal -->






		<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/purchase/purchase.blade.php ENDPATH**/ ?>