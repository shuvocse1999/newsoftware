<?php $i=1;  ?>
<?php if(isset($data)): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="tr<?php echo e($d->branch_id); ?>">
	<td><?php echo e($i++); ?></td>
	<td><?php echo e($d->branch_sl); ?></td>
	<td><?php echo e($d->company_name_en); ?><br><?php echo e($d->company_name_bn); ?></td>
	<td><?php echo e($d->branch_name_en); ?></td>
	<td><?php echo e($d->branch_name_bn); ?></td>
	<td><?php echo e($d->branch_mobile); ?></td>
	<td><?php echo $d->branch_address_en; ?></td>
	<td><?php echo $d->branch_address_bn; ?></td>
	<td><?php echo e($d->branch_email); ?></td>
	<td>
		<?php if($d->status == 1): ?>
		<span class="btn btn-success btn-sm border-0">Active</span>
		<?php else: ?>
		<span class="btn btn-warning btn-sm border-0">Inactive</span>
		<?php endif; ?>
	</td>
	<td>
		<a  class="btn btn-info border-0 edit text-light" data-toggle="modal" data-target="#exampleModalCenters" data-id="<?php echo e($d->branch_id); ?>"><i class="fa fa-pencil-square-o"></i></a>
		<a onclick="return confirm('Are you sure?')" class="delete btn btn-danger  border-0 text-light" data-id="<?php echo e($d->branch_id); ?>"><i class="fa fa-trash-o"></i></a>
	</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>







<script type="text/javascript">

	$(".delete").click(function(){
		let id = $(this).data('id');
		
		$.ajax(
		{
			url: "<?php echo e(url('deletebranch')); ?>/"+id,
			type: 'get',
			success: function()
			{
				$('#tr'+id).hide();

				Command:toastr["warning"]("Data Delete Successfully Done")
				toastr.options = {
					"closeButton": true,
					"debug": false,
					"newestOnTop": false,
					"progressBar": true,
					"positionClass": "toast-top-right",
					"preventDuplicates": false,
					"onclick": null,
					"showDuration": "300",
					"hideDuration": "1000",
					"timeOut": "3000",
					"extendedTimeOut": "1000",
					"showEasing": "swing",
					"hideEasing": "linear",
					"showMethod": "fadeIn",
					"hideMethod": "fadeOut"
				}

				showdata();
			},
			errors:function(){
				Command:toastr["danger"]("Data Delete Unsuccessfully")
				showdata();

			}
		});


	});

	// End Delete Data


	$(".edit").click(function(){
		var id = $(this).data("id");
		$.ajax(
		{
			url: "<?php echo e(url('editbranch')); ?>/"+id,
			type: 'get',
			data:{},
			success: function (data)
			{
				$(".editdata").html(data);
			}
		});

		
	});

  // End Edit Data

</script>
<?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/software/getbranch.blade.php ENDPATH**/ ?>