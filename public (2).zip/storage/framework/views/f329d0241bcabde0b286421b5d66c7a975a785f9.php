
<?php $__env->startSection('content'); ?>


<div class="content-wrapper">
	<div class="page-heading">
		<h3 class="page-title">Sales Payment List</h3>
	</div>



	<div class="page-content fade-in">
		<div class="ibox">
			<div class="ibox-head mb-3 myhead">
				<div class="ibox-title"><i class="fa fa-list-ul" aria-hidden="true"></i>&nbsp;&nbsp;Sales Payment List</div>
				<div><a href="<?php echo e(url('salespayment')); ?>" class="btn btn-dark rounded addbutton"><i class="fa fa-plus"></i>&nbsp;Sales Payment</a></div>
			</div>
			<div class="ibox-body table-responsive overflow">
				<table class="table table-striped table-bordered" id="example-table" cellspacing="0" width="100%">
					<thead class="mythead">
						<tr>
							<th>SL</th>
							<th>Payment Date</th>
							<th>Entry Date</th>
							<th>Customer Info.</th>
							<th>Payment</th>
							<th>Type</th>
							<th>Comment</th>
							<th>Action</th>
						</tr>
					</thead>
					
					<tbody class="tbody" id="showtdata">
						<?php $i=1;  ?>
						<?php if(isset($data)): ?>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($d->payment_amount > 0): ?>
						<tr id="tr<?php echo e($d->id); ?>">
							<td><?php echo e($i++); ?></td>
							<td><?php echo e($d->entry_date); ?></td>
							<td><?php echo e($d->entry_date); ?></td>
							<td><?php echo e($d->customer_name_en); ?>, <?php echo e($d->customer_phone); ?></td>
							<td><?php echo e($d->payment_amount); ?></td>
							<td><?php echo e($d->payment_type); ?></td>
							<td><?php echo e($d->note); ?></td>
							<td>
								<?php if($d->note != "firstpayment"): ?>
								<a href="<?php echo e(url("editsalespaymententry/".$d->id)); ?>" class="btn btn-info border-0 edit text-light"><i class="fa fa-pencil-square-o"></i></a>
								<?php endif; ?>
								<a href="<?php echo e(url("salespaymentinvoice/".$d->id)); ?>" class="btn btn-dark border-0 edit text-light" target="blank"><i class="fa fa-eye"></i></a>
								<?php if($d->note != "firstpayment"): ?>
								<a  class="delete btn btn-danger  border-0 text-light" data-id="<?php echo e($d->id); ?>"><i class="fa fa-trash-o"></i></a>
								<?php endif; ?>
							</td>

						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>

						
					</tbody>
				</table>
			</div>
		</div>

	</div>
</div>

<!-------End Table--------->


<script type="text/javascript">


	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		}
	});




	$(".delete").click(function(){
		let id = $(this).data('id');


		swal({
			title: "Delete Payment Entry?",
			icon: "info",
			buttons: true,
			dangerMode: true,

		})
		.then((willDelete) => {
			if (willDelete) {

				$.ajax(
				{
					url: "<?php echo e(url('deletesalesentry')); ?>/"+id,
					type: 'get',
					success: function()
					{
						$('#tr'+id).hide();

						Command:toastr["error"]("Delete Payment Entry Successfully")
						toastr.options = {
							"closeButton": true,
							"debug": false,
							"newestOnTop": false,
							"progressBar": true,
							"positionClass": "toast-top-right",
							"preventDuplicates": false,
							"onclick": null,
							"showDuration": "300",
							"hideDuration": "1000",
							"timeOut": "3000",
							"extendedTimeOut": "1000",
							"showEasing": "swing",
							"hideEasing": "linear",
							"showMethod": "fadeIn",
							"hideMethod": "fadeOut"
						}

						showsalesproductcart();
					},
					errors:function(){
						Command:toastr["danger"]("Data Delete Unsuccessfully")


					}
				});


			} else {

			}
		});
	});




	// End Delete Data
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/sales/salespaymentlist.blade.php ENDPATH**/ ?>