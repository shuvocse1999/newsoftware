	<?php $i=1;  ?>
	<?php if(isset($data)): ?>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr id="tr<?php echo e($d->id); ?>">
		<td><?php echo e($i++); ?></td>
		<td><?php echo e($d->invoice_date); ?></td>
		<td><?php echo e($d->invoice_no); ?></td>
		<td><?php echo e($d->voucher_no); ?></td>
		<td><?php echo e($d->supplier_company_name); ?>, <?php echo e($d->supplier_company_phone); ?></td>
		<td><?php echo e($d->transaction_type); ?></td>

		
		<td>
			<a class="delete btn btn-danger  border-0 text-light" data-id="<?php echo e($d->id); ?>"><i class="fa fa-trash-o"></i></a>
			<a href="<?php echo e(url('invoicepurchase/'.$d->invoice_no)); ?>" target="_blank"  class="btn btn-info  border-0 text-light"><i class="fa fa-eye"></i></a>
		</td>

	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

	<script type="text/javascript">
		$(".delete").click(function(){
			let id = $(this).data('id');


			swal({
				title: "Are you sure?",
				icon: "info",
				buttons: true,
				dangerMode: true,

			})
			.then((willDelete) => {
				if (willDelete) {

					$.ajax(
					{
						url: "<?php echo e(url('deletepurchaseledger')); ?>/"+id,
						type: 'get',
						success: function()
						{
							$('#tr'+id).hide();

							Command:toastr["warning"]("Delete Successfully Done")
							toastr.options = {
								"closeButton": true,
								"debug": false,
								"newestOnTop": false,
								"progressBar": true,
								"positionClass": "toast-top-right",
								"preventDuplicates": false,
								"onclick": null,
								"showDuration": "300",
								"hideDuration": "1000",
								"timeOut": "3000",
								"extendedTimeOut": "1000",
								"showEasing": "swing",
								"hideEasing": "linear",
								"showMethod": "fadeIn",
								"hideMethod": "fadeOut"
							}


						},
						errors:function(){
							Command:toastr["danger"]("Data Delete Unsuccessfully")


						}
					});

				}
			});

		});
	</script><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/purchase/searchpurchaseinvoice.blade.php ENDPATH**/ ?>