	
<?php $i=1;  ?>
<?php if(isset($data)): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="tr<?php echo e($d->id); ?>">
	<td><?php echo e($i++); ?></td>
	<td><?php echo e($d->pdt_name_en); ?><br><?php echo e($d->pdt_name_bn); ?></td>
	<td><?php echo e($d->purchase_price_withcost); ?> Tk.</td>
	<td><?php echo e($d->sale_price); ?> Tk.</td>
	<td><?php echo e($d->quantity); ?></td>
	<td><?php echo e($d->sales_qty); ?></td>
	<td><?php echo e($d->quantity-$d->sales_qty); ?></td>
	

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\newsoftware\resources\views/Admin/stock/searchproductstock.blade.php ENDPATH**/ ?>